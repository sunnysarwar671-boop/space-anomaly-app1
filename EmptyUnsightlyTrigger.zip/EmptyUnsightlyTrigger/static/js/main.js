/**
 * Space Anomaly Detector — Frontend Logic
 * Sections: stats, charts, anomaly cards, asteroid table
 */

// -------------------------------------------------------
// Utility helpers
// -------------------------------------------------------
function fmt(n) { return Number(n).toLocaleString(); }

function fmtDate(iso) {
  if (!iso) return "";
  const d = new Date(iso);
  return d.toLocaleString(undefined, {
    month: "short", day: "numeric",
    hour: "2-digit", minute: "2-digit", timeZoneName: "short",
  });
}

// -------------------------------------------------------
// Bootstrap — fetch from API, then render everything
// -------------------------------------------------------
async function loadData() {
  try {
    const response = await fetch("/api/data");

    if (!response.ok) {
      const err = await response.json().catch(() => ({}));
      showFatalError(err.error || "NASA API is currently unavailable. Please try again shortly.");
      return;
    }

    const data = await response.json();

    renderDataSourceBadge(data.data_source, data.cached_at);
    renderStats(data.stats);
    renderCharts(data.asteroids);
    renderAnomalies(data.anomalies);
    initTable(data.asteroids);

  } catch (err) {
    console.error("Failed to load asteroid data:", err);
    showFatalError("Could not reach the server. Please refresh.");
  }
}

function showFatalError(msg) {
  document.getElementById("anomaly-list").innerHTML =
    `<p style="color:#ff4757;text-align:center;grid-column:1/-1;">⚠️ ${msg}</p>`;
  document.getElementById("table-body").innerHTML =
    `<tr><td colspan="5" style="color:#ff4757;text-align:center;">⚠️ ${msg}</td></tr>`;
  const badge = document.getElementById("data-source-badge");
  badge.textContent = "🔴 UNAVAILABLE";
  badge.style.color = "var(--accent-red)";
  badge.style.borderColor = "var(--accent-red)";
  badge.style.background = "rgba(255,71,87,0.1)";
  document.getElementById("footer-mode").textContent = "Data unavailable";
}

// -------------------------------------------------------
// Data-source badge
// -------------------------------------------------------
function renderDataSourceBadge(source, cachedAt) {
  const badge = document.getElementById("data-source-badge");
  const footer = document.getElementById("footer-mode");
  if (!badge) return;

  if (source === "live") {
    badge.textContent   = "🟢 LIVE NASA DATA";
    badge.style.color   = "var(--accent-green)";
    badge.style.borderColor = "var(--accent-green)";
    badge.style.background  = "rgba(34,211,160,0.1)";
    footer.textContent  = "Live NASA NeoWs Data";
  } else {
    const when = cachedAt ? ` — last updated ${fmtDate(cachedAt)}` : "";
    badge.textContent   = `🟡 CACHED DATA${when}`;
    badge.style.color   = "#f59e0b";
    badge.style.borderColor = "#f59e0b";
    badge.style.background  = "rgba(245,158,11,0.1)";
    footer.textContent  = `Cached NASA Data${cachedAt ? " · " + fmtDate(cachedAt) : ""}`;
  }
}

// -------------------------------------------------------
// Dashboard stats
// -------------------------------------------------------
function renderStats(stats) {
  document.getElementById("stat-total").textContent     = fmt(stats.total);
  document.getElementById("stat-distance").textContent  = fmt(stats.avg_distance) + " km";
  document.getElementById("stat-speed").textContent     = fmt(stats.avg_speed) + " km/h";
  document.getElementById("stat-hazardous").textContent = stats.hazardous_count;
}

// -------------------------------------------------------
// Charts
// -------------------------------------------------------
function renderCharts(asteroids) {
  Chart.defaults.color = "#6b7a99";
  Chart.defaults.borderColor = "rgba(0,200,255,0.1)";
  renderScatterChart(asteroids);
  renderDonutChart(asteroids);
}

function renderScatterChart(asteroids) {
  const ctx = document.getElementById("scatter-chart").getContext("2d");
  const hazardous = asteroids.filter(a => a.hazardous)
    .map(a => ({ x: a.distance / 1_000_000, y: a.speed, name: a.name }));
  const safe = asteroids.filter(a => !a.hazardous)
    .map(a => ({ x: a.distance / 1_000_000, y: a.speed, name: a.name }));

  new Chart(ctx, {
    type: "scatter",
    data: {
      datasets: [
        { label: "Potentially Hazardous", data: hazardous,
          backgroundColor: "rgba(255,71,87,0.75)", pointRadius: 7, pointHoverRadius: 10 },
        { label: "Safe", data: safe,
          backgroundColor: "rgba(0,200,255,0.6)",  pointRadius: 6, pointHoverRadius: 9  },
      ],
    },
    options: {
      responsive: true, maintainAspectRatio: false,
      plugins: {
        legend: { position: "bottom", labels: { font: { family: "Rajdhani" }, padding: 14 } },
        tooltip: { callbacks: { label: (c) => {
          const p = c.raw;
          return [`📌 ${p.name}`, `Distance: ${fmt(Math.round(p.x*1_000_000))} km`, `Speed: ${fmt(p.y)} km/h`];
        }}},
      },
      scales: {
        x: { title: { display: true, text: "Distance (million km)", color: "#6b7a99" }, grid: { color: "rgba(0,200,255,0.06)" } },
        y: { title: { display: true, text: "Speed (km/h)",           color: "#6b7a99" }, grid: { color: "rgba(0,200,255,0.06)" } },
      },
    },
  });
}

function renderDonutChart(asteroids) {
  const ctx = document.getElementById("donut-chart").getContext("2d");
  const h = asteroids.filter(a =>  a.hazardous).length;
  const s = asteroids.filter(a => !a.hazardous).length;

  new Chart(ctx, {
    type: "doughnut",
    data: {
      labels: ["Hazardous", "Safe"],
      datasets: [{ data: [h, s],
        backgroundColor: ["rgba(255,71,87,0.8)", "rgba(0,200,255,0.7)"],
        borderColor:     ["rgba(255,71,87,1)",   "rgba(0,200,255,1)"],
        borderWidth: 2, hoverOffset: 8 }],
    },
    options: {
      responsive: true, maintainAspectRatio: false, cutout: "65%",
      plugins: {
        legend: { position: "bottom", labels: { font: { family: "Rajdhani" }, padding: 16 } },
        tooltip: { callbacks: { label: (c) => ` ${c.label}: ${c.raw} asteroids` } },
      },
    },
  });
}

// -------------------------------------------------------
// Anomaly cards
// -------------------------------------------------------
function renderAnomalies(anomalies) {
  const container = document.getElementById("anomaly-list");
  container.innerHTML = "";

  if (!anomalies.length) {
    container.innerHTML = '<p style="color:#22d3a0;text-align:center;">✅ No anomalies detected.</p>';
    return;
  }

  anomalies.forEach(a => {
    const card = document.createElement("div");
    card.className = `anomaly-card ${a.hazard_level}`;
    const reasons = a.reasons.map(r => `<span class="reason-tag">${r}</span>`).join("");
    card.innerHTML = `
      <div class="anomaly-name">☄️ ${a.name}</div>
      <span class="anomaly-badge ${a.hazard_level}">${a.hazard_level}</span>
      <div class="anomaly-stats">
        <div class="anomaly-stat"><span class="anomaly-stat-label">Distance</span><span class="anomaly-stat-value">${fmt(a.distance)} km</span></div>
        <div class="anomaly-stat"><span class="anomaly-stat-label">Speed</span><span class="anomaly-stat-value">${fmt(a.speed)} km/h</span></div>
        <div class="anomaly-stat"><span class="anomaly-stat-label">Diameter</span><span class="anomaly-stat-value">${fmt(a.diameter)} m</span></div>
      </div>
      <div class="anomaly-reasons">${reasons}</div>`;
    container.appendChild(card);
  });
}

// -------------------------------------------------------
// Asteroid Explorer Table
// -------------------------------------------------------
let _allAsteroids = [];
let _sortCol      = "distance";
let _sortAsc      = true;
let _filterMode   = "all";
let _searchQuery  = "";

function initTable(asteroids) {
  _allAsteroids = asteroids;

  // Wire up sort headers
  document.querySelectorAll(".sortable").forEach(th => {
    th.addEventListener("click", () => {
      const col = th.dataset.col;
      if (_sortCol === col) {
        _sortAsc = !_sortAsc;
      } else {
        _sortCol = col;
        _sortAsc = col === "name";  // ascending by default for name, descending for numbers
      }
      updateSortIcons();
      renderTable();
    });
  });

  // Wire up filter buttons
  document.querySelectorAll(".filter-btn").forEach(btn => {
    btn.addEventListener("click", () => {
      document.querySelectorAll(".filter-btn").forEach(b => b.classList.remove("active"));
      btn.classList.add("active");
      _filterMode = btn.dataset.filter;
      renderTable();
    });
  });

  // Wire up search input
  document.getElementById("table-search").addEventListener("input", (e) => {
    _searchQuery = e.target.value.toLowerCase();
    renderTable();
  });

  renderTable();
}

function updateSortIcons() {
  document.querySelectorAll(".sortable").forEach(th => {
    const icon = th.querySelector(".sort-icon");
    if (th.dataset.col === _sortCol) {
      icon.textContent = _sortAsc ? "↑" : "↓";
      th.classList.add("sorted");
    } else {
      icon.textContent = "⇅";
      th.classList.remove("sorted");
    }
  });
}

function renderTable() {
  let rows = [..._allAsteroids];

  // Filter by hazard
  if (_filterMode === "hazardous") rows = rows.filter(a =>  a.hazardous);
  if (_filterMode === "safe")      rows = rows.filter(a => !a.hazardous);

  // Filter by search query
  if (_searchQuery) {
    rows = rows.filter(a => a.name.toLowerCase().includes(_searchQuery));
  }

  // Sort
  rows.sort((a, b) => {
    let va = a[_sortCol], vb = b[_sortCol];
    if (typeof va === "string") {
      return _sortAsc ? va.localeCompare(vb) : vb.localeCompare(va);
    }
    return _sortAsc ? va - vb : vb - va;
  });

  const tbody = document.getElementById("table-body");
  const count = document.getElementById("table-count");

  if (!rows.length) {
    tbody.innerHTML = `<tr><td colspan="5" style="text-align:center;color:var(--text-muted);padding:30px;">No asteroids match your search.</td></tr>`;
    count.textContent = "";
    return;
  }

  count.textContent = `Showing ${rows.length} of ${_allAsteroids.length} asteroids`;

  tbody.innerHTML = rows.map(a => {
    const hazardCell = a.hazardous
      ? `<span class="table-badge hazardous">☢️ YES</span>`
      : `<span class="table-badge safe">✅ NO</span>`;
    return `
      <tr class="${a.hazardous ? "row-hazardous" : ""}">
        <td class="col-name">${a.name}</td>
        <td>${fmt(a.distance)}</td>
        <td>${fmt(a.speed)}</td>
        <td>${fmt(a.diameter)}</td>
        <td>${hazardCell}</td>
      </tr>`;
  }).join("");
}

// -------------------------------------------------------
// Bootstrap
// -------------------------------------------------------
document.addEventListener("DOMContentLoaded", loadData);
