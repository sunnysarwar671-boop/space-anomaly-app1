"""
Space Anomaly Detector - Flask Backend
Analyzes NASA asteroid data and highlights unusual patterns.

Data source: NASA NeoWs (Near Earth Object Web Service)
API docs: https://api.nasa.gov/#NeoWS
Uses DEMO_KEY by default (30 req/hour). Set NASA_API_KEY env var for higher limits.

Fallback strategy: if the API is unavailable, the last successful
fetch is read from cache.json and served instead of sample data.
"""

import os
import urllib.request
import urllib.error
import json
from datetime import date, timedelta, datetime, timezone
from flask import Flask, render_template, jsonify

app = Flask(__name__)

# -------------------------------------------------------
# NASA API SETTINGS
# -------------------------------------------------------
NASA_API_KEY = os.environ.get("NASA_API_KEY", "DEMO_KEY")
NASA_NEO_URL = "https://api.nasa.gov/neo/rest/v1/feed"

# File used to persist the last successful NASA response
CACHE_FILE = "cache.json"


# -------------------------------------------------------
# CACHE — LOAD & SAVE
# -------------------------------------------------------

def load_cache():
    """
    Read the last successful NASA dataset from cache.json.
    Returns a dict with keys 'asteroids' and 'cached_at',
    or None if no cache file exists yet.
    """
    if not os.path.exists(CACHE_FILE):
        return None
    try:
        with open(CACHE_FILE, "r") as f:
            return json.load(f)
    except (json.JSONDecodeError, OSError):
        return None


def save_cache(asteroids):
    """
    Persist a fresh asteroid list to cache.json, recording
    the UTC timestamp of when it was fetched.
    """
    payload = {
        "cached_at": datetime.now(timezone.utc).isoformat(),
        "asteroids":  asteroids,
    }
    try:
        with open(CACHE_FILE, "w") as f:
            json.dump(payload, f)
    except OSError as err:
        print(f"[Cache] Could not write cache: {err}")


# -------------------------------------------------------
# NASA API — FETCH & PARSE
# -------------------------------------------------------

def fetch_nasa_data():
    """
    Call the NASA NeoWs API for a 7-day window ending today.
    Returns a list of asteroid dicts, or None on failure.
    """
    end_date   = date.today()
    start_date = end_date - timedelta(days=6)

    url = (
        f"{NASA_NEO_URL}"
        f"?start_date={start_date}"
        f"&end_date={end_date}"
        f"&api_key={NASA_API_KEY}"
    )

    try:
        req = urllib.request.Request(url, headers={"User-Agent": "SpaceAnomalyDetector/1.0"})
        with urllib.request.urlopen(req, timeout=8) as response:
            raw = json.loads(response.read().decode())
    except (urllib.error.URLError, urllib.error.HTTPError, json.JSONDecodeError) as err:
        print(f"[NASA API] Request failed: {err}")
        return None

    return parse_nasa_response(raw)


def parse_nasa_response(raw):
    """
    Transform the NASA NeoWs JSON structure into our flat asteroid list.
    Each entry: name, distance (km), speed (km/h), diameter (m), hazardous.
    """
    asteroids = []

    for day_objects in raw.get("near_earth_objects", {}).values():
        for neo in day_objects:
            try:
                approach    = neo["close_approach_data"][0]
                distance_km = float(approach["miss_distance"]["kilometers"])
                speed_kmh   = float(approach["relative_velocity"]["kilometers_per_hour"])
                diam_m      = float(neo["estimated_diameter"]["meters"]["estimated_diameter_max"])
                hazardous   = bool(neo.get("is_potentially_hazardous_asteroid", False))
                name        = neo.get("name", "Unknown").strip("()")

                asteroids.append({
                    "name":      name,
                    "distance":  round(distance_km),
                    "speed":     round(speed_kmh),
                    "diameter":  round(diam_m),
                    "hazardous": hazardous,
                })
            except (KeyError, IndexError, ValueError):
                continue

    return asteroids if asteroids else None


# -------------------------------------------------------
# ANOMALY DETECTION
# -------------------------------------------------------

def detect_anomalies(asteroids):
    """
    Flag objects that are very close, very fast, or very large.
    Returns each anomaly with a CRITICAL / HIGH / MODERATE label.
    """
    anomalies = []
    for rock in asteroids:
        reasons = []
        score   = 0

        if rock["distance"] < 1_000_000:
            reasons.append("Dangerously close")
            score += 3

        if rock["speed"] > 60_000:
            reasons.append("Extreme velocity")
            score += 2

        if rock["diameter"] > 3_000:
            reasons.append("Massive size")
            score += 2

        if rock["hazardous"]:
            reasons.append("NASA-flagged hazardous")
            score += 1

        if reasons:
            hazard_level = "CRITICAL" if score >= 5 else ("HIGH" if score >= 3 else "MODERATE")
            anomalies.append({**rock, "reasons": reasons, "hazard_level": hazard_level})

    anomalies.sort(key=lambda x: x["distance"])
    return anomalies


def compute_stats(asteroids):
    """Compute summary statistics from the asteroid list."""
    total = len(asteroids)
    return {
        "total":           total,
        "avg_distance":    round(sum(a["distance"] for a in asteroids) / total),
        "avg_speed":       round(sum(a["speed"]    for a in asteroids) / total),
        "hazardous_count": sum(1 for a in asteroids if a["hazardous"]),
    }


# -------------------------------------------------------
# ROUTES
# -------------------------------------------------------

@app.route("/")
def index():
    return render_template("index.html")


@app.route("/api/data")
def api_data():
    """
    1. Try live NASA API.
    2. On failure, serve the last cached dataset.
    3. If no cache exists yet, return a clear error.
    """
    asteroids   = fetch_nasa_data()
    data_source = "live"
    cached_at   = None

    if asteroids:
        # Fresh data — update the cache for future fallbacks
        save_cache(asteroids)
        print(f"[Data] Loaded {len(asteroids)} asteroids from NASA NeoWs API.")
    else:
        # NASA unavailable — try the cache
        cache = load_cache()
        if cache:
            asteroids   = cache["asteroids"]
            cached_at   = cache["cached_at"]
            data_source = "cached"
            print(f"[Data] NASA API unavailable. Serving cached data from {cached_at}.")
        else:
            # No cache at all — return an error so the UI can inform the user
            print("[Data] NASA API unavailable and no cache found.")
            return jsonify({"error": "NASA API is currently unavailable and no cached data exists yet. Please try again shortly."}), 503

    stats     = compute_stats(asteroids)
    anomalies = detect_anomalies(asteroids)

    return jsonify({
        "data_source": data_source,
        "cached_at":   cached_at,
        "stats":       stats,
        "asteroids":   asteroids,
        "anomalies":   anomalies,
    })


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
