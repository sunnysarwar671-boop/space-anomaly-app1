# Space Anomaly Detector

A mobile-friendly web app that analyzes NASA asteroid data and highlights unusual patterns.

## Stack
- **Backend:** Python 3.11 + Flask
- **Production server:** Gunicorn (2 workers)
- **Frontend:** Vanilla JS + Chart.js, custom dark space CSS

## Structure
- `app.py` — Flask routes, NASA NeoWs API fetch, cache logic, anomaly detection
- `cache.json` — Auto-generated on first successful NASA fetch; used as fallback when API is unavailable
- `requirements.txt` — Python dependencies
- `templates/index.html` — Single-page HTML
- `static/css/style.css` — Dark space theme
- `static/js/main.js` — Charts, anomaly cards, sortable/filterable table

## Running locally
```
python app.py
```

## Production
Deployed as a **VM** (always-on) so `cache.json` persists between requests.
Run command: `gunicorn --bind=0.0.0.0:5000 --reuse-port --workers=2 app:app`

## User preferences
- Comments in code explaining what each part does
- Beginner-friendly structure
- Dark space theme with Orbitron font
